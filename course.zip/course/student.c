/**
 * @file student.c
 * @author William Zhang
 * @date April 7, 2022
 * @brief Student library for managing students (in particular, their grades). Includes definition of Student functions
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * Adds a grade to the student's list of grades. Increments the student's number of grades accordingly.
 *
 * @param student a student of type Student
 * @param grade a number of type double representing the grade to be added to the student's list of grades.
 * @return nothing
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;

  //If the student previously did not have any grades, memory must be allocated to add in grades for the student
  //If the student previously had grades, then the memory for those grades is reallocated to make space for the added grade.
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }

  //adjust value in index accordingly 
  student->grades[student->num_grades - 1] = grade;
}

/**
 * Calculate and return the student's average grade (from all the grades the student has).
 *
 * @param student a student of type Student who's average is being calculated and returned
 * @return a double value representing the average of the student input.
*/  
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 * Print student's information including full name, id, their individual grades, and the student's average
 * 
 * @param student of type Student - represents the student whose information is being printed
 * @return nothing
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * Given a predetermined number of grades 
 * generates a student with random values picked from the names list, a random id, and a random set of grades.
 *
 * @param grades an input of type integer that represents the number of grades the student will have.
 * @return type Student - a student with randomized attribute values
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  //allocate space for new student
  Student *new_student = calloc(1, sizeof(Student));

  //first and last name picked randomly from the above lists
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  //formula for randomly determining a student id
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  //generate random grades
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}
