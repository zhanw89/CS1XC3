/**
 * @file student.h
 * @author William Zhang
 * @date April 7, 2022
 * @brief Student library for managing students in a course - includes definition of Student and functions for the Student.
 */

/**
 * Student type stores a student with fields first and last name, student id, their grade(s), and the number of grades they have
 */
typedef struct _student 
{ 
  char first_name[50]; /**< student's first name */
  char last_name[50]; /**< student's last name */
  char id[11]; /**< student's id */
  double *grades; /**< student's grades */
  int num_grades; /**< the number of grades the student has */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
