/**
 *
 * @file course.c
 * @author Wiliam Zhang
 * @date April 7, 2022
 * @brief a library for managing courses, specifically student information for the course (enrolled, top student, passing status)
 *
 */


#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * enrolls (i.e. adds) a student to the course and dynamically allocates the space accordingly.
 *	Specifically if there is only one student in the course after the student will be added, 
 *	directly allocate space for a single student.
 *	Otherwise, dynamically reallocate space for the added student.
 *	Finally, assign the index for course->students to the pointer for the new student
 *	
 * @param *course a pointer to the memory address containing a course 
 * @param *student a pointer to the memory address containing a student
 *
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  } //Note the use of calloc here and realloc below. Calloc is used in the case the student being enrolled is the first one.
  //Memory must be allocated to make space for the enrolled student(s).
  //If there already exists memory containing enrolled students, we may simply reallocate that memory to make space for an additional one.
  //Hence the use of realloc below.
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * Prints the course name, code, total students, and the students in the course.
 *
 * @param course input of type Course representing the course who's info is being printed
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * Returns the student with the highest average in the course.
 *
 * @param course input of type Course for which the top student is being found.
 * @return output of pointer representing the student with the highest average in the course.
 */
Student* top_student(Course* course)
{
  //If there are no students in the course, there cannot be a top student	
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  //typical method of finding max. Parse through all items, first item set to max (above): if current item > max, set new max. 
  //Continue until end of list.
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * Returns a list of the students in the course who are passing (average of 50 or higher).
 *
 * @param course input of type Course of which the passing students are being found
 * @param *total_passing pointer to an int value in memory (represents the total number of students passing the course).
 * @return a list of type Student containing the students in the course who are passing.
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  //The function parses through the students in the course and counts the number of passing students.
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  //Function allocates memory for the number of students who are passing
  passing = calloc(count, sizeof(Student));

  //Function loops through the students again and adds the passing students into the passing list.
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  //the pointer input of *total_passing is assigned its appropriate value and may be used or printed as desired (similar to assigning 
  //variables a value in a void function for later/external use in the main function/file. 
  *total_passing = count;

  return passing;
}
