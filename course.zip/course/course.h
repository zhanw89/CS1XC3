/**
 * @file course.h
 * @author William Zhang
 * @date April 7, 2022
 * @brief course library for managing student information in a course. Includes definition of the course structure and functions involving
 *	  courses and students
 */	  

#include "student.h"
#include <stdbool.h>

/**
 * Course type stores a course with a course name, code, a list of Students (taking the course), 
 * and total number of students taking the course
 *
 */
typedef struct _course 
{
  char name[100]; /**< course name */
  char code[10]; /**< course code */
  Student *students; /**< the course has students and so holds them in a list*/
  int total_students; /**< Total number of students taking/enrolled in the course */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


