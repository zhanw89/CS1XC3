/**
 * @mainpage Course and Student function demonstration
 *
 * The Course and Student function demonstration shows how multiple functions in the Course and Student libraries work including:
 * - From Student:
 * - Generating random students (and adding grades for students)
 * - Printing students
 * - And inherently present in some course functions: taking the average of a student's grades 
 * - From Course:
 * - Enrolling a student in a course
 * - Printing a course
 * - Finding the top student in a course
 * - Finding the passing students in a course
 *
 * @file main.c
 * @author William Zhang
 * @date April 11, 2022
 * @brief Runs demonstration code for Course and Student library methods.
 *
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * Creates a course called MATH101 and assigns it a name and code.
 * Tests the various functions associated with Course and Student including 
 * printing outputs, and finding desired information of the course and students.
 *
 */
int main()
{
  srand((unsigned) time(NULL));

  //Allocate memory for and create MATH101 course.
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  //Enroll (20) randomly generated students (with 8 grades each) into the course.
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  //Print the MATH101 course alongside its information (testing the print course function).
  //This should include the course's name, code, total number of students, and the students taking the course.
  print_course(MATH101);

  //Test the top student Course function to determine the top performing student in the course based on student averages.
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student); //test the print_student Student function which should print the student's name, id, grades (list), and average

  //Test the passing Course function which returns a list of the passing students. 
  //Note here that the total_passing pointer is created and used as an input for the passing function.
  //The value assigned to the total_passing variable in the passing function is then printed, representing the total number of students 
  //passing the course.
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}
